import smtplib
import pyttsx3
import requests
import speech_recognition as sr
import datetime
import os
import cv2
import random
from requests import get
import wikipedia
import webbrowser
import pywhatkit as kit
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUiType
from DesktopUi import Ui_DesktopUi
import sys
import datetime


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0].id)
engine.setProperty('voices', voices[0].id)

# text to speech
def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()

# to convert voice into text
def takecommand(self):
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold = 1
        r.adjust_for_ambient_noise(source)
        # audio = r.listen(source)
        audio = r.listen(source,timeout=1,phrase_time_limit=5)

    try:
        print("Recognising....")
        query = r.recognize_google(audio, language='en-in')
        print(f"user said: {query}")

    except Exception as e:
        speak("Say that again please......")
        return "none"
    query = query.lower()
    return query

# engine = pyttsx3.init('sapi5')
# voices = engine.getProperty('voices');
# # print(voices[0].id)
# engine.setProperty('voices', voices[len(voices) - 1].id)

def speak(audio):#text to speech
    engine.say(audio)
    print(audio)
    engine.runAndWait()


    # to wish
def wish():
        hour = int(datetime.datetime.now().hour)
    
        if hour >=0 and hour <=12:
            speak("good morning, its ")
        elif hour>12 and hour<18:
            speak("good afternoon, its ")
        else:
            speak("good evening, its ")
            speak("how are u sir")
        speak("i am your Acer desktop assistant sir. please tell me how can i help you")

def mail(to,content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('bca01421502019@gmail.com', 'Mishr@9315')
    server.mail('bca01421502019@gmail.com', to, content)
    server.close()



class MainThread(QThread):
    def __init__(self):
        super(MainThread,self).__init__()

    def Run(self):
        self.TaskExecution()

def takecommand(self):
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold = 1
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)
        audio = r.listen(source,timeout=1,phrase_time_limit=5)

    try:
        print("Recognising....")
        query = r.recognize_google(audio, language='en-in')
        print(f"user said: {query}")
    
    except Exception as e:
        speak("Say that again please......")
        return "none"
    query = query.lower()
    return query


def TaskExecution(self):
# # if __name__ == "__main__":
#     # speak("this is 2 desktop")
#     # takecommand()
    # wish()
    # while True:
    self.query = self.takecommand()
        
    if 1:

        self.query = takecommand().lower()

        # logic building for tasks

    if "open notepad" in self.query:
            npath = "C:\\Windows\\system32\\notepad.exe"
            os.startfile(npath)

    elif "adobe reader" in self.query:
            apath = "C:\\Program Files (x86)\\Adobe\\Acrobat Reader DC\\Reader\\AcroRd32.exe"
            os.startfile(apath)

    elif "open command prompt" in self.query:
             os.system("start cmd")

    elif "open camera" in self.query:
            cap = cv2.VideoCapture(0)
            while True:
                ret, img = cap.read()
                cv2.imshow('webcam', img)
                k = cv2.waitKey(50)
                if k==27:
                    break;
            cap.release()
            cv2.destroyAllWindows()

    elif "play music" in self.query: 
            music_dir ="C:\\Users\\Adarsh\\Music\\Playlists"
            songs = os.listdir(music_dir)
            rd = random.choice(songs)                
            os.startfile(os.path.join(music_dir, rd)) 
            os.startfile(os.path.join(music_dir, songs[0]))
        
    elif "ip address" in self.query:
            ip = get('https://api.ipify.org').text
            speak(f"your IP address is {ip}")

    elif "wikipedia" in self.query:
            speak("searching wikipedia....")
            self.query = self.query.replace("wikipedia","")
            results = wikipedia.summary(self.query, sentences=5)
            speak("according to wikipedia...")
            speak(results)
            print(results)
         
    elif "open youtube" in self.query:
            webbrowser.open("www.youtube.com")
        
    elif "Facebook" in self.query:
            webbrowser.open("www.Facebook.com")

    elif "open stackoverflow" in self.query:
            webbrowser.open("www.stackoverflow.com")
        
    elif "open google" in self.query:
            speak("sir, what should i search on google")
            cm = takecommand().lower()
            webbrowser.open(f"{cm}")
        
    elif "message" in self.query:
            kit.sendwhatmsg("+918810413131", "this is testing protocol",7,37)

    elif "songs on youtube" in self.query:
            kit.playonyt("see you again")

    elif "mail" in self.query:
            try:
                speak("what should i say?")
                content = takecommand().lower()
                to = "mishraadarsh375@gmail.com"
                mail(to,content)
                speak("mail has been sent to adi")
                
            except Exception as e:
                print(e)
                speak('sorry sir, i am not able to sent this mail')
    
    elif "no thanks" in self.query:
            speak("thanks for using me sir, have a good day")
            # sys.exit()

    speak("sir, do you have anyy other work")

startExecution = MainThread()

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_DesktopUi()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)

    def startTask(self):
        self.ui.movie = QtGui.QMovie("C:/Users/Adarsh/Pictures/Saved Pictures/desktop.gif")
        self.ui.label.setMovie(self.ui.movie)
        self.ui.movie.start()
        self.ui.movie = QtGui.QMovie("C:/Users/Adarsh/Pictures/Saved Pictures/desktop5.gif")
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()
        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)
        startExecution.start()

    def showTime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time = current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)


app = QApplication(sys.argv)
Desktop = Main()
Desktop.show()
# exit(app.exec_())

from numpy import dtype
import pyttsx3
import speech_recognition as sr
import datetime
import os
import cv2
import random
from requests import get
import wikipedia
import webbrowser
import pywhatkit as kit
import smtplib
import sys
import time
import urllib.request
import numpy as np
import requests
from bs4 import BeautifulSoup
# from twilio.rest import Client

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0].id)
engine.setProperty('voices', voices[0].id)

# text to speech
def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()

# to convert voice into text
def takecommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold = 1
        audio = r.listen(source,timeout=2.0,phrase_time_limit=5)

    try:
        print("Recognising....")
        query = r.recognize_google(audio, language='en-in')
        print(f"user said: {query}")

    except Exception as e:
        speak("Say that again please......")
        return "none"
    return query

    # to wish
def wish():
        hour = int(datetime.datetime.now().hour)
    
        if hour>=0 and hour<=12:
            speak("good morning")
        elif hour>12 and hour<18:
            speak("good afternoon")
        else:
            speak("good evening")
        speak("how are u sir")    
        speak("I am your Acer desktop assistant sir. please tell me how can i help you")
        

def sendEmail(to,content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('bca01421502019@gmail.com', 'Mishr@9315')
    server.sendmail('bca01421502019@gmail.com', to, content)
    server.close()


if __name__ == "__main__":
    # speak("this is 2 desktop")
    # takecommand()
    wish()
    while True:
    # if 1:

        query = takecommand().lower()

        #logic building for tasks

        if "open notepad" in query:
            npath = "C:\\Windows\\system32\\notepad.exe"
            os.startfile(npath)

        elif "adobe reader" in query:                   
            apath = "C:\\Program Files\\Adobe\\Acrobat DC\\Acrobat\\Acrobat.exe"
            os.startfile(apath)

        elif "open command prompt" in query:
             os.system("start cmd")

        elif "camera" in query:
            cap = cv2.VideoCapture(0)
            while True:
                ret, img = cap.read()
                cv2.imshow('webcam', img)
                k = cv2.waitKey(50)
                if k==27:
                    break;
            cap.release()
            cv2.destroyAllWindows()
        elif "play song" in query:
            music_dir ="C:\\Users\\Adarsh\\Music\\Playlists"
            songs = os.listdir(music_dir)
            # rd = random.choice(songs)                 to play random songs
            # os.startfile(os.path.join(music_dir, rd)) random module
            os.startfile(os.path.join(music_dir, songs[0]))
        

        elif "temperature" in query:
            search = "temperature in delhi"
            url = f"https://www.google.com/search?q={search}"
            r = requests.get(url)
            data = BeautifulSoup(r.text,"html.parser")
            temp = data.find("div", class_="BNeawe").text
            speak(f"current {search} is {temp}")
           
        # from twilio.rest import Client


        elif "ip address" in query:
            ip = get('https://api.ipify.org').text
            speak(f"your IP address is {ip}")

        elif "wikipedia" in query:
            speak('Searching Wikipedia....')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            speak(results)
            print(results)
         
        elif "open youtube" in query:
            webbrowser.open("www.youtube.com")
        
        elif " open facebook" in query:
            webbrowser.open("www.facebook.com")

        elif " open stackoverflow" in query:
            webbrowser.open("stackoverflow.com")
        
        elif "open google" in query:
            speak("sir, what should i search on google")
            cm = takecommand().lower()
            webbrowser.open(f"{cm}")
        
        elif "message" in query:
            kit.sendwhatmsg("+918810413131", "this is testing protocol",15,00)

        elif "songs on youtube" in query:
            kit.playonyt("see you again")

        elif "email" in query:
            try:
                speak("what should i say?")
                content = takecommand()
                to = "mishraadarsh375@gmail.com"
                sendEmail(to,content)
                speak("Email has been sent to adi")
                
            except Exception as e:
                print(e)
                speak("sorry sir, i am not able to sent this mail")
    
        elif "no thanks" in query:
            speak("thanks for using me sir, have a good day")
            sys.exit()

        speak("sir, do you have anyy other work")
















































