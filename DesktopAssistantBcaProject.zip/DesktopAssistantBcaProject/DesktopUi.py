










from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_DesktopUi(object):
    def setupUi(self, DesktopUi):
        DesktopUi.setObjectName("DesktopUi")
        DesktopUi.resize(1059, 666)
        self.centralwidget = QtWidgets.QWidget(DesktopUi)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(20, 270, 701, 371))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("C:/Users/Adarsh/Pictures/Saved Pictures/desktop.gif"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(460, 600, 93, 28))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("background-color: rgb(255, 255, 0);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(557, 600, 121, 28))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("background-color: rgb(255, 0, 0);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(20, 20, 471, 251))
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("C:/Users/Adarsh/Pictures/Saved Pictures/desktop5.gif"))
        self.label_2.setObjectName("label_2")
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)# text browser
        self.textBrowser.setGeometry(QtCore.QRect(309, 280, 181, 50))
        font = QtGui.QFont()
        font.setFamily("Nirmala UI")
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        self.textBrowser.setFont(font)
        self.textBrowser.setStyleSheet("background:transparent;\n"
"border-radius:none;\n"
"color:white;\n"
"font-size:20px;")
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser_2.setGeometry(QtCore.QRect(490, 280, 221, 51))
        font = QtGui.QFont()
        font.setFamily("Nirmala UI")
        font.setPointSize(16)
        font.setBold(True)
        font.setWeight(75)
        self.textBrowser_2.setFont(font)
        self.textBrowser_2.setStyleSheet("background:transparent;\n"
"border-radius:none;\n"
"color:white;\n"
"font-size:20px;")
        self.textBrowser_2.setObjectName("textBrowser_2")
        DesktopUi.setCentralWidget(self.centralwidget)

        self.retranslateUi(DesktopUi)
        QtCore.QMetaObject.connectSlotsByName(DesktopUi)

    def retranslateUi(self, DesktopUi):
        _translate = QtCore.QCoreApplication.translate
        DesktopUi.setWindowTitle(_translate("DesktopUi", "MainWindow"))
        self.pushButton.setText(_translate("DesktopUi", "Run"))
        self.pushButton_2.setText(_translate("DesktopUi", "Terminate"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    DesktopUi = QtWidgets.QMainWindow()
    ui = Ui_DesktopUi()
    ui.setupUi(DesktopUi)
    DesktopUi.show()
    sys.exit(app.exec_())













































































